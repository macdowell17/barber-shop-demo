# Peso Barber Lounge

Branded demo website. Upload `index.html` to the root of your GitHub repository and deploy as a static site on Vercel.

**Demo only:** Booking requests are saved in the visitor’s browser, not sent to the barber. No real bookings, payments, or reminders are active. Service prices and times are placeholders.
