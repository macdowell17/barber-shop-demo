# The Barber Shop — Website Demo

A single-file responsive barber website, ready for GitHub and Vercel.

## Deploy
1. Create a new GitHub repository (for example, `barber-shop-demo`).
2. Upload `index.html` to the repository root.
3. In Vercel, choose **Add New → Project**, import the repo, choose **Other** as the framework if prompted, and deploy.
4. Open the generated `.vercel.app` URL.

## Important
This is a **visual/demo prototype**, not a production booking system. The booking form saves sample requests only to the visitor's own browser using localStorage. It does not send booking requests to the business, block conflicting slots, charge no-show fees, or send SMS/email reminders. Before launch, integrate a real scheduling platform and set accurate prices, hours, location, policies, and contact information. Do not invite real customers to submit personal data through the demo form.

The demo uses remotely hosted Unsplash images; replace with licensed shop photos before production.
